import cv2
import qrcode
import sqlite3
from twilio.rest import Client
 
account_sid = 'ACc0abd5139ecff02f1ab900828aac1733'
auth_token = '0122aa64d39a64a184c2a1b3f2c381e2'
twilio_client = Client(account_sid, auth_token)
twilio_phone_number = 'whatsapp:+5951076184',

conn = sqlite3.connect('La_base_de_datos.db')
cursor = conn.cursor()
 
cursor.execute('''CREATE TABLE IF NOT EXISTS alumnos (
                nombre TEXT,
                telefono TEXT,
                cuenta TEXT,
                qr_code TEXT)''')
 
# Mensajes de whatsaap 
def send_whatsapp_message(to, message):
    twilio_client.messages.create(
        body=message,
        from_=twilio_phone_number,
        to='whatsapp:+5951076184'
    )
 
# Datos personales del alumno 
nombre_alumno = "Cristian Ignacio Ayala Ballina"
telefono = "5543168512"
numero_cuenta = "1615757"
 
# Crear el código QR
contenido_qr = f"Nombre: {nombre_alumno}\nTeléfono: {telefono}\nCuenta: {numero_cuenta}"
 
# Generar el código QR
qr = qrcode.QRCode(
    version=1,
    error_correction=qrcode.constants.ERROR_CORRECT_L,
    box_size=10,
    border=4,
)
qr.add_data(contenido_qr)
qr.make(fit=True)
 
img = qr.make_image(fill_color="black", back_color="white")
 

qr_filename = f"{nombre_alumno}_qr.png"
img.save(qr_filename)
 
cursor.execute("INSERT INTO alumnos (nombre, telefono, cuenta, qr_code) VALUES (?, ?, ?, ?)",
               (nombre_alumno, telefono, numero_cuenta, qr_filename))
conn.commit()
 
# Escanear el código QR
print("Escanea el código QR para confirmar el registro.")
camera = cv2.VideoCapture(0)  
while True:
    ret, frame = camera.read()
    if ret:
        detector = cv2.QRCodeDetector()
        decoded_info, _, _ = detector.detectAndDecode(frame)
        if decoded_info:  
            if contenido_qr == decoded_info:
                print("Registro Completado.")
                send_whatsapp_message(twilio_phone_number, f"¡El alumno {nombre_alumno} se ha documentado!")
                break
            else:
                print("Código QR no coincide con el documento.")
        cv2.imshow("QR Code Scanner", frame)
    if cv2.waitKey(1) == 27:  
        break
camera.release()
cv2.destroyAllWindows()
conn.close()

